package com.example.androidversions;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import java.util.ArrayList; // استيراد ArrayList لتطابق السلايدات
import com.example.androidversions.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity  {

    private ActivityMainBinding mainBinding;
    private final ArrayList<AndroidVersion> VersionList = new ArrayList<>();
    private AndroidVersionAdapter Adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mainBinding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(mainBinding.getRoot());

        VersionList.add(new AndroidVersion(R.mipmap.ic_launcher, "Donut", "1.6"));
        VersionList.add(new AndroidVersion(R.mipmap.ic_launcher, "Éclair", "2.0"));
        VersionList.add(new AndroidVersion(R.mipmap.ic_launcher, "Froyo", "2.2"));
        VersionList.add(new AndroidVersion(R.mipmap.ic_launcher, "Gingerbread", "2.3"));
        VersionList.add(new AndroidVersion(R.mipmap.ic_launcher, "Honeycomb", "3.0"));
        VersionList.add(new AndroidVersion(R.mipmap.ic_launcher, "Ice Cream Sandwich", "4.0"));
        VersionList.add(new AndroidVersion(R.mipmap.ic_launcher, "Jelly Bean", "4.1"));
        VersionList.add(new AndroidVersion(R.mipmap.ic_launcher, "KitKat", "4.4"));
        VersionList.add(new AndroidVersion(R.mipmap.ic_launcher, "Lollipop", "5.0"));
        VersionList.add(new AndroidVersion(R.mipmap.ic_launcher, "Marshmallow", "6.0"));
        VersionList.add(new AndroidVersion(R.mipmap.ic_launcher, "Nougat", "7.0"));
        VersionList.add(new AndroidVersion(R.mipmap.ic_launcher, "Oreo", "8.0"));

        Adapter = new AndroidVersionAdapter(this, VersionList);
        mainBinding.recyclerView.setAdapter(Adapter);
        mainBinding.recyclerView.setLayoutManager(new LinearLayoutManager(this));
    }
}



