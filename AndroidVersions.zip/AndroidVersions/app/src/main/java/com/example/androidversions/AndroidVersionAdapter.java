package com.example.androidversions;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList; // استيراد ArrayList بناءً على السلايدات
import com.example.androidversions.databinding.ItemAndroidVersionBinding;

public class AndroidVersionAdapter extends RecyclerView.Adapter<AndroidVersionAdapter.VersionViewHolder> {

    private final ArrayList<AndroidVersion> VersionList;
    private Context Context;

    public AndroidVersionAdapter(Context context, ArrayList<AndroidVersion> versionList) {
        this.VersionList = versionList;
        this.Context = context;
    }

    @NonNull
    @Override
    public AndroidVersionAdapter.VersionViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemAndroidVersionBinding binding = ItemAndroidVersionBinding.inflate(
                LayoutInflater.from(parent.getContext()), parent, false);
        return new VersionViewHolder(binding, this);
    }

    @Override
    public void onBindViewHolder(@NonNull AndroidVersionAdapter.VersionViewHolder holder, int position) {

        AndroidVersion myVersion = VersionList.get(position);
        holder.binding.imgLogo.setImageResource(myVersion.imageId);
        holder.binding.CodeName.setText(myVersion.codeName);
        holder.binding.Version.setText(myVersion.version);

        if (position % 2 == 0) {
            holder.binding.cardView.setCardBackgroundColor(Context.getResources().getColor(android.R.color.white));
            holder.binding.CodeName.setTextColor(Context.getResources().getColor(android.R.color.black));
            holder.binding.Version.setTextColor(Context.getResources().getColor(android.R.color.darker_gray));
        } else {
            holder.binding.cardView.setCardBackgroundColor(Context.getResources().getColor(android.R.color.holo_blue_light));
            holder.binding.CodeName.setTextColor(Context.getResources().getColor(android.R.color.white));
            holder.binding.Version.setTextColor(Context.getResources().getColor(android.R.color.white));
        }
    }

    @Override
    public int getItemCount() {

        return VersionList.size();
    }

    class VersionViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        final ItemAndroidVersionBinding binding;
        final AndroidVersionAdapter myAdapter;

        public VersionViewHolder(@NonNull ItemAndroidVersionBinding binding, AndroidVersionAdapter adapter) {
            super(binding.getRoot());
            this.binding = binding;
            this.myAdapter = adapter;
            binding.getRoot().setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            int mPosition = getLayoutPosition();
            AndroidVersion element = VersionList.get(mPosition);

            String message = "You selected : " + element.codeName + " (" + element.version + ")";
            Toast.makeText(Context, message, Toast.LENGTH_SHORT).show();
        }
    }
}





