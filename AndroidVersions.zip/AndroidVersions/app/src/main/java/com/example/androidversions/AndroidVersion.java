package com.example.androidversions;

public class AndroidVersion {
    int imageId;
    String codeName;
    String version;


    public AndroidVersion(int imageId, String codeName, String version) {
        this.imageId = imageId;
        this.codeName = codeName;
        this.version = version;
    }
}